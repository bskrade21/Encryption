# Encryption
My Information Security Cryptography Assignment. This is a simple program that takes a message and then hashes it, encrypts it and then decrypts it. I doesn't have too many applications as is but with some modification it could be quite useful.
