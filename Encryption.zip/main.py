from cryptography.fernet import Fernet
import hashlib

#Generate the key
key = Fernet.generate_key()
cipher_suite = Fernet(key)

#Converting a string into its ascii equivalent
print('Type something you would like to encode below:')
a = input('')
bytes = bytes(a, "ascii")
print()

#Hashing the string
hash_message = hashlib.md5(a.encode())
print('Hashed message:')
print(hash_message.hexdigest())
print()

#print the bit string
print('Bit string:')
print(' '.join(["{0:b}".format(x) for x in bytes]))
print()

#Encode the bit string and print
encoded_text = cipher_suite.encrypt(bytes)
print('Encoded text:')
print(encoded_text.decode('utf-8')) #.decode('utf-8') removes the b' '
print()

#Decode the encoded text and print
print('Decoded text:')
decoded_text = cipher_suite.decrypt(encoded_text)
print(decoded_text.decode('utf-8'))